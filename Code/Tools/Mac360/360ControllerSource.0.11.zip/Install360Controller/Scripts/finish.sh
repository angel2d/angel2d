#!/bin/sh

/usr/bin/touch /System/Library/Extensions

exit 0
