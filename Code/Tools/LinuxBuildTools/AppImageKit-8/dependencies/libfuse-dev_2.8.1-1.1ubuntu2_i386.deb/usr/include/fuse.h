/*
   This header is for compatibility with older software using FUSE.

   Please use 'pkg-config --cflags fuse' to set include path.  The
   correct usage is still '#include <fuse.h>', not '#include
   <fuse/fuse.h>'.
*/

#include "fuse/fuse.h"
